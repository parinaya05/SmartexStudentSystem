Project: Student Record Management System
Author: K Parinaya Sri

Features:
- Add Student (Scholar or Regular)
- Display details
- Append remarks
- Calculate grade (bonus marks for ScholarStudent)
- Compare names
- Simulate exception

Technologies:
- Java, OOP: inheritance, interface, abstract class, method overriding
- Custom exception
- Menu-driven program

How to run:
1. Open in Eclipse
2. Run StudentApp.java
3. Test all menu options

Thank you!
