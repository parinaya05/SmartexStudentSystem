package smartex;

/**
 * Interface PersonInfo
 * Declares methods to display basic info and get type of student.
 */
public interface PersonInfo {
    void displayBasicInfo();
    String getType();
}
